package com.sal.feed;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SalService {
@Autowired
SalRepository salRepository;
	public SalService() {
		// TODO Auto-generated constructor stub
	}

	public void saveEmpSal(EmpSal sal) {
		// TODO Auto-generated method stub
		salRepository.save(sal);
	}

	public List<EmpSal> getSalaries() {
		// TODO Auto-generated method stub
		return salRepository.findAll();
	}

}
