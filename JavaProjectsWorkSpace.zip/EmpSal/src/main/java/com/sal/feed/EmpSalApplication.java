package com.sal.feed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpSalApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpSalApplication.class, args);
	}

}
