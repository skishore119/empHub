package com.sal.feed;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class SalController {
@Autowired
SalService salService;
	public SalController() {
		// TODO Auto-generated constructor stub
	}
@PostMapping("/sal")
public void saveempSalary(@RequestBody EmpSal sal) {
	salService.saveEmpSal(sal);
}
@GetMapping("/sal")
public List<EmpSal> getSalaries(){
	return salService.getSalaries();
}
}
