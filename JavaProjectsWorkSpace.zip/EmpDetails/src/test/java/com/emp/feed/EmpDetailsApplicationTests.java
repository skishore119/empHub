package com.emp.feed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
