package com.emp.feed;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emp_details")
public class EmpModel {

	public EmpModel() {
		// TODO Auto-generated constructor stub
	}
	@Id
private String empid;
private String name;
private String designation;
private String salary;
@Override
public String toString() {
	return "EmpModel [empid=" + empid + ", name=" + name + ", desgination=" + designation + ", salary=" + salary + "]";
}
public EmpModel(String empid, String name, String desgination, String salary) {
	super();
	this.empid = empid;
	this.name = name;
	this.designation = desgination;
	this.salary = salary;
}
public String getEmpid() {
	return empid;
}
public void setEmpid(String empid) {
	this.empid = empid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDesgination() {
	return designation;
}
public void setDesgination(String desgination) {
	this.designation = desgination;
}
public String getSalary() {
	return salary;
}
public void setSalary(String salary) {
	this.salary = salary;
}
}
