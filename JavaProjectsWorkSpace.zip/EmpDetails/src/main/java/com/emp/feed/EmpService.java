package com.emp.feed;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class EmpService {
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	EmpRepository empRepository;
	public EmpService() {
		// TODO Auto-generated constructor stub
	}

	public List<EmpModel> getEmpDetails() {
		// TODO Auto-generated method stub
		List<EmpModel> emp = new ArrayList<>();
		List<EmpSal> sals = new ArrayList<>();
		ResponseEntity<List<EmpSal>> sal =
		        restTemplate.exchange("http://localhost:8081/sal",
		                    HttpMethod.GET, null, new ParameterizedTypeReference<List<EmpSal>>() {
		            });
		sals.addAll(sal.getBody());
		sals.stream().forEach(obj->{
			
			Optional<EmpModel> employee = empRepository.findById(obj.getEmpid());
			
			if(employee.isPresent()) {
				EmpModel model = employee.get();
				model.setSalary(obj.getSalary());
				emp.add(model);
			}
		});
		return emp;
		
	}

	public void saveEmpDetails(EmpModel emp) {
		// TODO Auto-generated method stub
		empRepository.save(emp);
	}

	public Optional<EmpModel> getEmpById(String id) {
		// TODO Auto-generated method stub
		return empRepository.findById(id);
	}


}
