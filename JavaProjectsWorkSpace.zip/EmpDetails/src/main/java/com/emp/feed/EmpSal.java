package com.emp.feed;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emp_salaries")
public class EmpSal {

	public EmpSal() {
		// TODO Auto-generated constructor stub
	}
	@Id
	private String empid;
	private String salary;
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public EmpSal(String empid, String salary) {
		super();
		this.empid = empid;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "EmpSal [empid=" + empid + ", salary=" + salary + "]";
	}
	

}
