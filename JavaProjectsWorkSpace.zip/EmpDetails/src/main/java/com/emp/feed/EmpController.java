package com.emp.feed;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class EmpController {
	@Autowired
	EmpService empService;
	@GetMapping("/emp")
	public List<EmpModel> getempDetails(){
		return empService.getEmpDetails();
	}
	@PostMapping("/emp")
	public void saveempDetails(@RequestBody EmpModel emp) {
		empService.saveEmpDetails(emp);
	}
	@GetMapping("/emp/{id}")
	public Optional<EmpModel> getEmpById(@PathVariable String id) {
		return empService.getEmpById(id);
	}
}
